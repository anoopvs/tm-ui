export class Task {
    taskId:number;
    task: String;
    priority: number;
    parentTask: String;
    startDate: Date;
    endDate:Date;
    activeTask: boolean; 
}
